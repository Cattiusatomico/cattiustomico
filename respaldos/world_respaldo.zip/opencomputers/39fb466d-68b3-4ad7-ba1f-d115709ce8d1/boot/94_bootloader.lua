io.write("Welcome to TherOS!\n")
os.execute("/sys/env/main.lua")